# Discord-Nuke-Bot-V2
A Discord Nuke bot Made By [ TheAxes ]  Give Credits If You post Somewhere else: 🖕



# Features 🔥
1. -[x] NukeAll
2. -[x] MassBan
3. -[x] MassKick
4. -[x] DelChannel
5. -[x] delroles
6. -[x] adminall

## Extra
1. -[x] Help
2. -[x] serverinfo
3. -[x] Shutdown

### How To Use
Skip This If You Running On Replit Direct Fork Link At Last
1. Clone Repo
```
git clone https://github.com/TheAxes/Discord-Nuke-Bot-V2.git
```
2. CD CLONED REPO
```
cd Discord-Nuke-Bot-V2
```
3. Put Bot Token Or Configure other setting in config.json
4. Run It
```
python main.py 
```


Made By - TheAxes

[Youtube](https://www.youtube.com/channel/UCMEhNSLa2O6WQqtqpjwu-sw)


# Vedio Tutorial 
[![Youtube](https://media.discordapp.net/attachments/984383210710507590/1001911829087391844/download_1.jpeg)](https://youtu.be/PiVOMD0sLb4)
[![Run on Repl.it](https://repl.it/badge/github/replit/replbox)](https://replit.com/github/TheAxes/Discord-Nuke-Bot-V2)

<a href="https://www.buymeacoffee.com/AshOp" target="_blank"><img src="https://cdn.buymeacoffee.com/buttons/v2/default-yellow.png" alt="Buy Me A Coffee" style="height: 60px !important;width: 217px !important;" ></a>
